setClass('kineticWavelets',
		representation(h5='character',reff='character'),
	prototype(h5=NULL,reff=NULL,DNAPattern=NULL)
)


