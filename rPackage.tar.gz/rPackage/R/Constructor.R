kineticWavelets  <- function(h5,reff){
	h5=PacBioCmph5(h5)
	reff=read.fasta(reff)
	return(new("kineticWavelets",h5=h5,reff=h5))
}
